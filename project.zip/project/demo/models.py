# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models


# Create your models here.
class Register(models.Model):
	email=models.CharField(max_length=50)
	password=models.CharField(max_length=20)

class Post_it(models.Model):
	user_email=models.CharField(max_length=50)
	title=models.TextField(max_length=100)
	description=models.TextField(max_length=250)
	question=models.TextField(max_length=500)
	answer=models.TextField(max_length=1000)
	def __str__(self):
		return self.title