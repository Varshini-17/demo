from django.conf.urls import url,include

from . import views

urlpatterns = [
    # url('', views.index, name='index'),
    url('register/', views.register, name='register'),
    url('login/', views.login_request, name='login_request'),
    url('home/', views.home, name='home'),
    url('create_post/', views.create_post, name='create_post'),
]