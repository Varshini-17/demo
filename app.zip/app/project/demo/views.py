# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,redirect

# Create your views here.
from django.http import HttpResponse
from django.contrib.auth import login, authenticate,logout
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from models import *
from forms import *
from django.core.exceptions import ValidationError
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.hashers import check_password
from django.http.response import HttpResponse, JsonResponse
def index(request):

    return HttpResponse("Hello, world. You're at the polls index.")

def register(request):
	if request.method=="POST":
		form=UserCreationForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('/login/')
	else:
		form=UserCreationForm()
	return render(request,"register/register.html",{"form":form})

def login_request(request):
	if request.method=="POST":
		email=request.POST.get('email')
		password=request.POST.get('password')
		form=AuthenticationForm(data=request.POST)
		if form.is_valid():
			user=form.get_user()
			login(request,user)
			return redirect("/home/")
	else:
		form=LoginForm()
	return render(request,"register/login.html",{"form":form})


@login_required
def home(request):
	data={}
	posts=[]
	email=request.user.username
	posts=Post_it.objects.values().filter(user_email=email)
	if request.method=="GET":
		query=request.GET.get("q")
		# data['query']=str(query)
		# return data
	if request.method=="POST":
		logout(request)
		messages.info(request,"LOGGED OUT successfully")
		return redirect("/register/")

	else:
		data=Post()
	return render(request,"home.html",{"form":data,"posts":posts})

@login_required
def create_post(request):
	email=request.user.username
	if request.method=="POST":
		post=Post(request.POST)
		if post.is_valid():
			title=post.cleaned_data['title']
			description=post.cleaned_data['description']
			question=post.cleaned_data['question']
			answer=post.cleaned_data['answer']
			create_post=Post_it(title=title,description=description,question=question,answer=answer,user_email=email)
			create_post.save()
		return redirect('/home/')	
	else:
		post=Post()
	return render(request,"home.html", {"form":post})



# @login_required
# def search(query=None):
# 	queryset=[]
# 	queries=query.split(" ")
# 	for item in queries:
# 		post=Post.objects.filter(
# 			Q(title__icontraints=item)|
# 			Q(body__icontraints=item)
# 			).distinct()
# 		for items in post:
# 			queryset.append(items)
# 	return list(set(queryset))