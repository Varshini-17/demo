# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,redirect

# Create your views here.
from django.http import HttpResponse
from django.contrib.auth import login, authenticate,logout
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from models import *
from forms import *
from django.core.exceptions import ValidationError
from django.contrib import messages
from django.contrib.auth.decorators import login_required
def index(request):

    return HttpResponse("Hello, world. You're at the polls index.")

def register(request):
	# form=UserCreationForm()
	print(request.POST)
	if request.method=="POST":
		form=RegisterForm(request.POST)
		if form.is_valid():
			form.save()
			messages.success(request,"Account successfully created")
			return redirect('/login/')
	else:
		form=RegisterForm()
	return render(request,"register/register.html",{"form":form})

def login_request(request):
	if request.method=="POST":
		form=LoginForm(request.POST)
		email=request.POST.get('email')
		password=request.POST.get('password')
		if Register.objects.filter(email=email, password=password).exists():
			# return redirect('/home/')
			messages.info(request,'WELCOME')
			return redirect("/home/")
		else:
			messages.error(request,'Please check the credentials')
			return redirect('/login/')
	else:
		form=LoginForm()
	return render(request,"register/login.html",{"form":form})

def logout(request):
	logout(request)
	messages.info(request,"LOGGED OUT successfully")
	return render(request,'register/register.html')

@login_required
def home(request):
	print("home")
	return render(request,"home.html")